sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("advancesubmitform.controller.advancesubmitform", {
            onInit: function () {

            },
            onPress: async function (oEvent) {
                debugger

                var po_number = oEvent.oSource.oParent.oParent.mAggregations.items[0].mAggregations.items[1].mProperties.value
                var contract_no = oEvent.oSource.oParent.oParent.mAggregations.items[1].mAggregations.items[1].mProperties.value
                var vendor_code = oEvent.oSource.oParent.oParent.mAggregations.items[4].mAggregations.items[1].mProperties.value

                debugger
                var fname = "getcallfromodata";
                let fname1 = this.getView().getModel().bindContext(`/${fname}(...)`);
                fname1.setParameter('po_number', po_number);
                fname1.setParameter('contract_no', contract_no);
                fname1.setParameter('vendor_code', vendor_code);

                try {
                    await fname1.execute();
                } catch (error) {
                    debugger
                    console.log(error)
                }
                console.log("func completed");
            }        
               
             });
            
    });
